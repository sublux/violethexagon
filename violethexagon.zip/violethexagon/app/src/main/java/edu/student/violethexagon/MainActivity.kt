package edu.student.violethexagon

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main.*
import kotlin.random.Random

class MainActivity : AppCompatActivity() {

    val summonList = arrayListOf("Fire Giant's Battleaxe", "Pufferfish Blowgun", "Boomerang of Lightning", "Club of the Chief", "Flashtooth Dagger",
        "Turtle Shell Flail", "Glaive of the Ancients", "Skysplitter Greataxe", "Thunderous Greatclub", "Seasinger Greatsword", "Elvish Halberd",
        "Handaxe of Rain", "Javelin of Fire", "Icicle Lance", "Dwarven Longbow", "Acidic Longsword", "Mace of the Mountain", "Elder Maul",
        "Morningstar of the Night", "Electrode Net", "Pike of Trickery", "Scimitar of the Redstone", "Shortbow of Famine",
        "Sickle of Silver", "Veteran's Sling", "Maelstrom Trident", "Sunshard Spear", "Brass Warhammer", "Abyssal Whip")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        summonBtn.setOnClickListener {
            val random = Random
            val randomWeapon = random.nextInt(summonList.count())

            weaponTxt.text= summonList[randomWeapon]
        }


    }
}
